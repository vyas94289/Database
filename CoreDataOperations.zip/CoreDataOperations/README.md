# CoreDataOperations
Core Data Operations Like Insert, Update, Fetch, Delete etc. Using Swift 3.
![Screenshot](coredata.png)
